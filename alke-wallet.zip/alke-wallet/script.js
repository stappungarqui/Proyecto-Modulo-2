$(document).ready(function() {
  
  // --- Inicialización del saldo base y el historial ---
  if (!localStorage.getItem('saldoWallet')) {
    localStorage.setItem('saldoWallet', '1500000');
  }
  if (!localStorage.getItem('historialWallet')) {
    const inicial = JSON.stringify([{ detalle: "Depósito Inicial", tipo: "ingreso", monto: 1500000 }]);
    localStorage.setItem('historialWallet', inicial);
  }

  // Cargar saldo actual en el menú flotante si el elemento existe
  if ($('#txtSaldo').length) {
    let saldoActual = parseInt(localStorage.getItem('saldoWallet'));
    $('#txtSaldo').text(`$${saldoActual.toLocaleString('es-CL')}`);
    // Animación de entrada suave exigida en la UX de jQuery
    $('.card').hide().fadeIn(800);
  }

  // --- 1. LÓGICA DE INICIO DE SESIÓN (login.html) ---
  $('#loginForm').on('submit', function(e) {
    e.preventDefault();
    const correo = $('#email').val();
    const clave = $('#password').val();

    if (correo === 'admin@alkewallet.com' && clave === 'wallet1234') {
      alert('¡Acceso correcto!');
      window.location.href = 'menu.html';
    } else {
      alert('Credenciales incorrectas. Intente nuevamente.');
    }
  });

  // --- 2. LÓGICA DE DEPÓSITO (deposit.html) ---
  $('#depositForm').on('submit', function(e) {
    e.preventDefault();
    const monto = parseInt($('#montoDeposito').val());
    let saldoActual = parseInt(localStorage.getItem('saldoWallet'));

    // Modificación de fondos y persistencia
    saldoActual += monto;
    localStorage.setItem('saldoWallet', saldoActual.toString());

    // Registro en el historial
    let historial = JSON.stringify([{ detalle: "Depósito realizado", tipo: "ingreso", monto: monto }]);
    let historialAnterior = JSON.parse(localStorage.getItem('historialWallet'));
    historialAnterior.unshift({ detalle: "Depósito realizado", tipo: "ingreso", monto: monto });
    localStorage.setItem('historialWallet', JSON.stringify(historialAnterior));

    alert(`¡Depósito exitoso de $${monto.toLocaleString('es-CL')} realizado correctamente!`);
    window.location.href = 'menu.html';
  });

  // --- 3. LÓGICA DE TRANSFERENCIA (sendmoney.html) ---
  $('#transferForm').on('submit', function(e) {
    e.preventDefault();
    const monto = parseInt($('#montoTransferir').val());
    const contacto = $('#destinatario').val();
    let saldoActual = parseInt(localStorage.getItem('saldoWallet'));

    if (monto > saldoActual) {
      alert('Error: No cuentas con fondos suficientes para esta transacción.');
      return;
    }

    // Restar saldo de la memoria
    saldoActual -= monto;
    localStorage.setItem('saldoWallet', saldoActual.toString());

    // Guardar en el historial estructurado
    let historialAnterior = JSON.parse(localStorage.getItem('historialWallet'));
    historialAnterior.unshift({ detalle: `Transferencia a ${contacto}`, tipo: "egreso", monto: monto });
    localStorage.setItem('historialWallet', JSON.stringify(historialAnterior));

    alert(`¡Transferencia enviada con éxito a ${contacto}!`);
    window.location.href = 'menu.html';
  });

  // --- 4. LÓGICA DEL HISTORIAL (transactions.html) ---
  if ($('#listaMovimientos').length) {
    let historial = JSON.parse(localStorage.getItem('historialWallet')) || [];
    let tablaHTML = '';

    // Renderizado dinámico de transacciones con clases Bootstrap
    historial.forEach(function(item) {
      if (item.tipo === 'ingreso') {
        tablaHTML += `<tr><td>${item.detalle}</td><td class="text-right text-success font-weight-bold">+$${item.monto.toLocaleString('es-CL')}</td></tr>`;
      } else {
        tablaHTML += `<tr><td>${item.detalle}</td><td class="text-right text-danger font-weight-bold">-$${item.monto.toLocaleString('es-CL')}</td></tr>`;
      }
    });

    $('#listaMovimientos').html(tablaHTML);
  }
});
